package io.naav97.balance_checker_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BalanceCheckerApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(BalanceCheckerApiApplication.class, args);
	}

}
